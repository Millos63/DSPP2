﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto1erParcialAutos
{
    internal interface ITransmision
    {
        string Transmision();
        Boolean EsTiptronic();
    }
}
